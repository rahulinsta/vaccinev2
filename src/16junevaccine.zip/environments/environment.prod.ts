export const environment = { 
  production: true,
  apiurl:'https://vaccine2.showmeproject.com/api/v2/',
  imgurl:'https://vaccine2.showmeproject.com/admin/public/storage/',
};